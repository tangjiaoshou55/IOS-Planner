//
//  DetailView.swift
//  exercise
//
//  Created by Johnathan Tang on 1/21/24.
//

import SwiftUI

struct DetailView: View {
    // TODO
}

#Preview {
    // TODO
}
